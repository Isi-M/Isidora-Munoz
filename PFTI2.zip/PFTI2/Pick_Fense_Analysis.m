function [FWHMs,mean_FWHMs,locsMAX]=Pick_Fense_Analysis(Image,Leaf_Points,MinPeak,MinLeafDistance)

Normalized_Image=(Image-min(Image))./(max(Image)-min(Image));
for i=1:length(Leaf_Points)
    [pks,locs,w,p] = findpeaks(single(Normalized_Image(:,Leaf_Points(i))),'MinPeakHeight',MinPeak,'MinPeakDistance',MinLeafDistance,'Annotate','extents','WidthReference','halfheight');
    FWHMs{1,i}=w(:)';
end
mean_FWHMs=[];
[pks,locsMAX]=findpeaks(single(Normalized_Image(:,Leaf_Points(i))),'MinPeakHeight',MinPeak,'MinPeakDistance',MinLeafDistance,'Annotate','extents','WidthReference','halfheight');
for k=1:length(FWHMs)
    mean_FWHMs(k)=mean(FWHMs{1,k}(:));
end
end