function [Leaf_Points,Half_line,locs_Edge_Leafs]=Leaf_Finder(Image,Alto,Distancia,IntensidadMin)

%%Find Mid Pick
Normalized_Image=(Image-min(Image))./(max(Image)-min(Image));
Image_Size=size(Image);
plot(Normalized_Image(:,Image_Size(1)./2))
[pks,locs] = findpeaks((Normalized_Image(:,Image_Size(1)./2)),'MinPeakHeight',Alto);
Half_line=locs(round(end/2));
%findpeaks(single(Normalized_Image(:,Image_Size(1)./2)),'MinPeakHeight',0.5,'Annotate','extents','WidthReference','halfheight');


%Find Leafs 
Normalized_Line=(Image(Half_line,:)-min(Image(Half_line,:)))./(max(Image(Half_line,:))-min(Image(Half_line,:)));
[pks,locs_Edge_Leafs]=findpeaks(single(Normalized_Line),'MinPeakProminence',IntensidadMin,'MinPeakDistance',Distancia,'Annotate','extents');
locs_Edge_Leafs=(horzcat(1,locs_Edge_Leafs));
locs_Edge_Leafs(end+1)=Image_Size(2);
%imagesc(Image)
Leaf_Points=locs_Edge_Leafs(1:end-1)+(locs_Edge_Leafs(2:end)-locs_Edge_Leafs(1:end-1))./2;
%hold on;
%scatter(locs_Edge_Leafs(1:end-1)+(locs_Edge_Leafs(2:end)-locs_Edge_Leafs(1:end-1))./2,550,'filled','red')
