function [ima] = import_test2
[file,path] = uigetfile('*.*');
if file == 0
    return
end
ima2=(imread(strcat(path,'\',file)));
ima=double(rgb2gray(ima2));
