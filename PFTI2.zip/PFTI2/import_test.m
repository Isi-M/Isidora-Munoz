function [ima] = import_test
[file,path] = uigetfile('*.*');
if file == 0
    return
end
ima=double(dicomread(strcat(path,'\',file)));
info=dicominfo(strcat(path,'\',file));

